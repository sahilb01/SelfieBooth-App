package com.example.printimage

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.print.PrintHelper
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var countdownText: TextView
    private lateinit var takePhotoBtn: Button
    private lateinit var flashOverlay: View
    private var imageCapture: ImageCapture? = null
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var usbPrinterHelper: UsbPrinterHelper
    private var lastPhotoFile: File? = null

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.example.printimage.USB_PERMISSION") {
                val granted = intent.getBooleanExtra(android.hardware.usb.UsbManager.EXTRA_PERMISSION_GRANTED, false)
                if (granted && lastPhotoFile != null) {
                    Toast.makeText(context, "Permission granted, printing now...", Toast.LENGTH_SHORT).show()
                    printPhoto(lastPhotoFile!!)
                } else {
                    Toast.makeText(context, "USB permission denied", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Hide system UI for full-screen immersive experience
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        supportActionBar?.hide()

        previewView = findViewById(R.id.previewView)
        countdownText = findViewById(R.id.countdownText)
        takePhotoBtn = findViewById(R.id.takePhotoBtn)
        flashOverlay = findViewById(R.id.flashOverlay)

        usbPrinterHelper = UsbPrinterHelper(this)
        cameraExecutor = Executors.newSingleThreadExecutor()

        registerReceiver(
            usbPermissionReceiver,
            IntentFilter("com.example.printimage.USB_PERMISSION")
        )

        checkCameraPermission()

        takePhotoBtn.setOnClickListener {
            startCountdownAndCapture()
        }
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 100)
        } else {
            startCamera()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .build()
                .also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
            } catch (exc: Exception) {
                exc.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startCountdownAndCapture() {
        takePhotoBtn.isEnabled = false
        countdownText.visibility = TextView.VISIBLE
        countdownText.alpha = 1f

        object : CountDownTimer(5000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                countdownText.text = "${millisUntilFinished / 1000}"

                val fadeAnim = AlphaAnimation(0f, 1f)
                fadeAnim.duration = 300
                countdownText.startAnimation(fadeAnim)
            }

            override fun onFinish() {
                countdownText.visibility = TextView.GONE
                triggerFlashEffect()
                takePhoto()
            }
        }.start()
    }

    private fun triggerFlashEffect() {
        flashOverlay.visibility = View.VISIBLE
        val flashAnim = AlphaAnimation(1f, 0f)
        flashAnim.duration = 400
        flashOverlay.startAnimation(flashAnim)
        flashOverlay.postDelayed({ flashOverlay.visibility = View.GONE }, 400)
    }

    private fun takePhoto() {
        val photoFile = File(externalCacheDir, "photo_${System.currentTimeMillis()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()
        lastPhotoFile = photoFile

        imageCapture?.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    printPhoto(photoFile)
                    takePhotoBtn.isEnabled = true
                }

                override fun onError(exc: ImageCaptureException) {
                    exc.printStackTrace()
                    takePhotoBtn.isEnabled = true
                }
            }
        )
    }

    private fun printPhoto(photoFile: File) {
        val original = BitmapFactory.decodeFile(photoFile.absolutePath)
        val size = minOf(original.width, original.height)
        val x = (original.width - size) / 2
        val y = (original.height - size) / 2
        val squareBitmap = Bitmap.createBitmap(original, x, y, size, size)
        val resized = Bitmap.createScaledBitmap(squareBitmap, 1000, 1000, true)

        when {
            usbPrinterHelper.isHPPrinter() -> {
                // ✅ HP Neverstop / LaserJet printers use PrintHelper
                val printHelper = PrintHelper(this)
                printHelper.scaleMode = PrintHelper.SCALE_MODE_FIT
                printHelper.printBitmap("SelfieBooth Photo", resized)
                Toast.makeText(this, "Printing via HP Print Service...", Toast.LENGTH_SHORT).show()
            }

            usbPrinterHelper.isPrinterConnected() -> {
                // ✅ USB mini/thermal printer direct OTG print
                val stream = ByteArrayOutputStream()
                resized.compress(Bitmap.CompressFormat.JPEG, 100, stream)
                val imageBytes = stream.toByteArray()
                usbPrinterHelper.printRawData(imageBytes)
                Toast.makeText(this, "Printing via USB printer...", Toast.LENGTH_SHORT).show()
            }

            else -> {
                // ✅ Fallback: no printer connected → default print dialog
                val printHelper = PrintHelper(this)
                printHelper.scaleMode = PrintHelper.SCALE_MODE_FIT
                printHelper.printBitmap("SelfieBooth Photo", resized)
                Toast.makeText(this, "No printer detected — using system print dialog", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbPermissionReceiver)
        cameraExecutor.shutdown()
    }
}

//val printHelper = PrintHelper(this)
//printHelper.scaleMode = PrintHelper.SCALE_MODE_FIT
//printHelper.printBitmap("SelfieBooth Photo", resized)
//Toast.makeText(this, "Printing via HP Print Service Plugin...", Toast.LENGTH_SHORT).show()

