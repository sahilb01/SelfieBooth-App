package com.example.printimage

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.*
import android.util.Log
import android.widget.Toast
import java.io.IOException

class UsbPrinterHelper(private val context: Context) {

    private val ACTION_USB_PERMISSION = "com.example.printimage.USB_PERMISSION"
    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    /** ✅ Check if any USB printer is connected */
    fun isPrinterConnected(): Boolean {
        val deviceList = usbManager.deviceList
        for (device in deviceList.values) {
            if (isPrinterDevice(device)) {
                Log.d("USB", "🖨 Printer detected: ${device.deviceName}")
                return true
            }
        }
        Log.d("USB", "❌ No printer connected")
        return false
    }

    /** ✅ Detect if connected printer is HP (Neverstop / LaserJet) */
    fun isHPPrinter(): Boolean {
        val deviceList = usbManager.deviceList
        for (device in deviceList.values) {
            if (isPrinterDevice(device)) {
                val manufacturer = device.manufacturerName?.lowercase() ?: ""
                val product = device.productName?.lowercase() ?: ""
                if ("hp" in manufacturer || "laserjet" in product || "neverstop" in product) {
                    Log.d("USB", "🔹 Detected HP Printer: ${device.productName}")
                    return true
                }
            }
        }
        return false
    }

    /** ✅ Send raw data to the USB printer (used for small printers) */
    fun printRawData(data: ByteArray) {
        val device = usbManager.deviceList.values.firstOrNull { isPrinterDevice(it) }
        if (device == null) {
            Log.e("USB", "❌ No compatible USB printer found")
            Toast.makeText(context, "No printer detected", Toast.LENGTH_SHORT).show()
            return
        }

        val permissionIntent = PendingIntent.getBroadcast(
            context,
            0,
            Intent(ACTION_USB_PERMISSION),
            PendingIntent.FLAG_IMMUTABLE
        )

        if (!usbManager.hasPermission(device)) {
            usbManager.requestPermission(device, permissionIntent)
            Toast.makeText(context, "Please tap 'Allow' to connect printer", Toast.LENGTH_SHORT).show()
            Log.d("USB", "⚠️ Requesting permission for ${device.deviceName}")
            return
        }

        sendToPrinter(device, data)
    }

    /** ✅ Internal method for actual data transfer */
    private fun sendToPrinter(device: UsbDevice, data: ByteArray) {
        val connection = usbManager.openDevice(device) ?: run {
            Log.e("USB", "❌ Could not open USB connection")
            return
        }

        val usbInterface = device.getInterface(0)
        val endpoint = (0 until usbInterface.endpointCount)
            .map { usbInterface.getEndpoint(it) }
            .firstOrNull { it.direction == UsbConstants.USB_DIR_OUT }

        if (endpoint == null) {
            Log.e("USB", "❌ No OUT endpoint found for printer")
            return
        }

        connection.claimInterface(usbInterface, true)

        try {
            val result = connection.bulkTransfer(endpoint, data, data.size, 2000)
            if (result > 0) {
                Log.d("USB", "✅ Data sent: $result bytes")
                Toast.makeText(context, "Printing photo...", Toast.LENGTH_SHORT).show()
            } else {
                Log.e("USB", "⚠️ Failed to send data to printer ($result)")
            }
        } catch (e: IOException) {
            e.printStackTrace()
        } finally {
            connection.releaseInterface(usbInterface)
            connection.close()
        }
    }

    /** ✅ Detects if the USB device is a printer */
    private fun isPrinterDevice(device: UsbDevice): Boolean {
        return device.deviceClass == UsbConstants.USB_CLASS_PRINTER ||
                (device.interfaceCount > 0 &&
                        device.getInterface(0).interfaceClass == UsbConstants.USB_CLASS_PRINTER)
    }
}
